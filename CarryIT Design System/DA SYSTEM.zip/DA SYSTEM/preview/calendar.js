(function () {
  function init() {
    var el = document.getElementById('dsCalendar');
    if (!el || !window.calendarjs) return;

    window.calendarjs.setDictionary({
      January: 'Janvier', February: 'Février', March: 'Mars', April: 'Avril',
      May: 'Mai', June: 'Juin', July: 'Juillet', August: 'Août',
      September: 'Septembre', October: 'Octobre', November: 'Novembre', December: 'Décembre',
      Sunday: 'Dimanche', Monday: 'Lundi', Tuesday: 'Mardi', Wednesday: 'Mercredi',
      Thursday: 'Jeudi', Friday: 'Vendredi', Saturday: 'Samedi',
    });

    var Calendar = window.calendarjs.Calendar;
    Calendar(el, {
      type: 'inline',
      value: new Date(2026, 5, 5),
      startingDay: 1,
      footer: false,
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
